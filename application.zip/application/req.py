import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import argparse
import sys
import os

# Disable output from python file
sys.stdout = open(os.devnull, 'w')

# Parse arguments passed to script
parser = argparse.ArgumentParser()
parser.add_argument("-a", type=str)
args = parser.parse_args()
arguments = args.a
arrayArgs = list(arguments)
#print(arrayArgs)

# Parse array
fromLang = str(arrayArgs[0] + arrayArgs[1])
toLang = str(arrayArgs[2] + arrayArgs[3])
del arrayArgs[0:4]
string = "".join(arrayArgs)
if fromLang == "hw":
    fromLang = "haw"
if fromLang == "hm":
    fromLang = "hmn"
if fromLang == "ce":
    fromLang = "ceb"
if fromLang == "cn":
    fromLang = "zh-CN"
if toLang == "hw":
    toLang = "haw"
if toLang == "hm":
    toLang = "hmn"
if toLang == "ce":
    toLang = "ceb"
if toLang == "cn":
    toLang = "zh-CN"

# Chrome does not open with the headless option
chromeoptions = Options()
chromeoptions.add_argument("--headless")
path = "chrome.exe"

# Retrieves html
browser = webdriver.Chrome(options=chromeoptions)
browser.get("https://translate.google.co.uk/#view=home&op=translate&sl=" + fromLang + "&tl=" + toLang + "&text=" + string)
time.sleep(3)
html = browser.page_source

# Trimming the html for appropriate storage
htmlArray = list(html)
del htmlArray[224250:len(htmlArray)]
del htmlArray[218750:223250]
del htmlArray[0:217750]
newHtml = "".join(htmlArray)
#print(newHtml.find(string))

# Writing to file for stdin to c
dataOutfile = open("htmlTranslateOut.txt", "w")
dataOutfile.write(newHtml)

browser.close()
